import API from './api';

export const login = async (credentials) => {
  const { data } = await API.post('/auth/login', credentials);
  if (data.token) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.usuario));
  }
  return data;
};

export const registrar = async (datos) => {
  const { data } = await API.post('/auth/registrar', datos);
  return data;
};

export const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
};

export const obtenerEventos = async () => {
  const { data } = await API.get('/eventos');
  return data;
};

export const crearEvento = async (datos) => {
  const { data } = await API.post('/eventos', datos);
  return data;
};

export const obtenerMapaEvento = async (eventoId) => {
  const { data } = await API.get(`/tickets/mapa/${eventoId}`);
  return data;
};

export const configurarMapa = async (eventoId, zonas) => {
  const { data } = await API.post(`/tickets/mapa/${eventoId}/configurar`, { zonas });
  return data;
};

export const bloquearAsiento = async (asientoId) => {
  const { data } = await API.post('/tickets/bloquear', { asientoId });
  return data;
};

export const liberarAsiento = async (asientoId) => {
  const { data } = await API.post('/tickets/liberar', { asientoId });
  return data;
};

export const comprarTicket = async (asientoId) => {
  const { data } = await API.post('/tickets/comprar', { asientoId });
  return data;
};

export const obtenerMisTickets = async () => {
  const { data } = await API.get('/tickets/mis-tickets');
  return data;
};

export const validarTicket = async (codigoQr) => {
  const { data } = await API.post(`/tickets/validar/${encodeURIComponent(codigoQr)}`);
  return data;
};
