import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  login, logout,
  obtenerEventos, crearEvento,
  obtenerMapaEvento, configurarMapa,
  bloquearAsiento, liberarAsiento, comprarTicket,
  obtenerMisTickets, validarTicket
} from './services/ticketService';

const ESTADOS_COLOR = {
  disponible: 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300',
  reservado_mio: 'bg-sky-600 text-white ring-2 ring-sky-400 border-sky-400',
  reservado_otro: 'bg-amber-900 text-amber-400 border-amber-700 cursor-not-allowed',
  vendido: 'bg-rose-950/60 text-rose-700 border-rose-900/50 cursor-not-allowed'
};

export default function App() {
  const [usuario, setUsuario] = useState(null);
  const [email, setEmail] = useState('admin@eurotickets.com');
  const [password, setPassword] = useState('123456');
  const [mensaje, setMensaje] = useState({ tipo: '', texto: '' });
  const [tab, setTab] = useState('eventos');

  const [listaEventos, setListaEventos] = useState([]);
  const [nuevoEvento, setNuevoEvento] = useState({
    nombre: '', descripcion: '', fecha: '', imagen_url: '',
    recinto_nombre: '', recinto_direccion: ''
  });

  const [eventoSeleccionado, setEventoSeleccionado] = useState(null);
  const [mapaData, setMapaData] = useState({ zonas: [], asientos: [] });
  const [nuevaZonaForm, setNuevaZonaForm] = useState({ nombre: '', precio: '', color: '#3b82f6', fila: '', cantidad: '' });

  const [asientoSeleccionado, setAsientoSeleccionado] = useState(null);
  const [tiempoRestante, setTiempoRestante] = useState(0);
  const timerRef = useRef(null);

  const [listaTickets, setListaTickets] = useState([]);
  const [ticketModal, setTicketModal] = useState(null);

  const [codigoValidar, setCodigoValidar] = useState('');
  const [resultadoValidacion, setResultadoValidacion] = useState(null);

  useEffect(() => {
    const userGuardado = localStorage.getItem('user');
    if (userGuardado) {
      setUsuario(JSON.parse(userGuardado));
      cargarEventos();
    }
  }, []);

  useEffect(() => {
    if (tiempoRestante <= 0) {
      clearInterval(timerRef.current);
      return;
    }
    timerRef.current = setInterval(() => setTiempoRestante((prev) => prev - 1), 1000);
    return () => clearInterval(timerRef.current);
  }, [tiempoRestante]);

  useEffect(() => {
    if (tiempoRestante === 0 && asientoSeleccionado) {
      setAsientoSeleccionado(null);
      setMensaje({ tipo: 'error', texto: '⏱️ El tiempo de reserva de 10 minutos ha expirado.' });
      if (eventoSeleccionado) cargarMapa(eventoSeleccionado.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tiempoRestante]);

  const mostrarError = (err, fallback) => {
    setMensaje({ tipo: 'error', texto: err.response?.data?.mensaje || fallback });
  };

  const cargarEventos = async () => {
    try {
      const res = await obtenerEventos();
      setListaEventos(res.eventos || []);
    } catch (err) { mostrarError(err, 'No se pudieron cargar los eventos'); }
  };

  const cargarMapa = async (eventoId) => {
    try {
      const res = await obtenerMapaEvento(eventoId);
      setMapaData({ zonas: res.zonas || [], asientos: res.asientos || [] });
    } catch (err) { mostrarError(err, 'No se pudo cargar el mapa del evento'); }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await login({ email, password });
      setUsuario(res.usuario);
      cargarEventos();
    } catch (err) { mostrarError(err, 'Credenciales inválidas'); }
  };

  const handleLogout = () => {
    logout();
    setUsuario(null);
    setListaEventos([]);
    setEventoSeleccionado(null);
    setAsientoSeleccionado(null);
    setTiempoRestante(0);
  };

  const seleccionarEvento = async (evento) => {
    if (asientoSeleccionado) await liberarAsiento(asientoSeleccionado.id);
    setAsientoSeleccionado(null);
    setTiempoRestante(0);
    setEventoSeleccionado(evento);
    cargarMapa(evento.id);
  };

  const handleCrearEvento = async (e) => {
    e.preventDefault();
    try {
      await crearEvento(nuevoEvento);
      setMensaje({ tipo: 'exito', texto: 'Evento creado correctamente.' });
      setNuevoEvento({ nombre: '', descripcion: '', fecha: '', imagen_url: '', recinto_nombre: '', recinto_direccion: '' });
      cargarEventos();
    } catch (err) { mostrarError(err, 'Error al crear el evento'); }
  };

  const handleAgregarZona = async (e) => {
    e.preventDefault();
    if (!eventoSeleccionado) return;
    try {
      const zonasExistentes = (mapaData.zonas || []).map((z) => {
        const asientosZona = mapaData.asientos.filter((a) => a.zona_id === z.id);
        const filasMap = {};
        asientosZona.forEach((a) => { filasMap[a.fila] = (filasMap[a.fila] || 0) + 1; });
        const filas = Object.keys(filasMap).map((f) => ({ fila: f, cantidad: filasMap[f] }));
        return { nombre: z.nombre, precio: z.precio, color: z.color, filas };
      });

      const nuevaZona = {
        nombre: nuevaZonaForm.nombre,
        precio: parseFloat(nuevaZonaForm.precio),
        color: nuevaZonaForm.color || '#3b82f6',
        filas: [{ fila: nuevaZonaForm.fila, cantidad: parseInt(nuevaZonaForm.cantidad, 10) }]
      };

      await configurarMapa(eventoSeleccionado.id, [...zonasExistentes, nuevaZona]);
      setMensaje({ tipo: 'exito', texto: 'Zona agregada al mapa del evento.' });
      setNuevaZonaForm({ nombre: '', precio: '', color: '#3b82f6', fila: '', cantidad: '' });
      cargarMapa(eventoSeleccionado.id);
    } catch (err) { mostrarError(err, 'Error al agregar la zona'); }
  };

  const handleClickAsiento = async (asiento, zona) => {
    if (asiento.estado === 'vendido') return;
    const esMio = asientoSeleccionado && asientoSeleccionado.id === asiento.id;

    if (esMio) {
      await liberarAsiento(asiento.id);
      setAsientoSeleccionado(null);
      setTiempoRestante(0);
      cargarMapa(eventoSeleccionado.id);
      return;
    }

    const esReservadoPorOtro = asiento.estado === 'reservado' && asiento.bloqueado_por !== usuario.id;
    if (esReservadoPorOtro) {
      setMensaje({ tipo: 'error', texto: 'Ese asiento está siendo reservado por otra persona.' });
      return;
    }

    try {
      if (asientoSeleccionado) await liberarAsiento(asientoSeleccionado.id);
      await bloquearAsiento(asiento.id);
      setAsientoSeleccionado({ id: asiento.id, fila: asiento.fila, numero: asiento.numero, precio: zona.precio, zonaNombre: zona.nombre });
      setTiempoRestante(600);
      cargarMapa(eventoSeleccionado.id);
    } catch (err) {
      mostrarError(err, 'El asiento ya no está disponible');
      cargarMapa(eventoSeleccionado.id);
    }
  };

  const handleComprar = async () => {
    if (!asientoSeleccionado) return;
    try {
      const res = await comprarTicket(asientoSeleccionado.id);
      setMensaje({ tipo: 'exito', texto: '¡Compra procesada con éxito!' });
      setTicketModal({
        codigoQr: res.codigoQr,
        evento: eventoSeleccionado.nombre,
        asiento: `${asientoSeleccionado.zonaNombre} — Fila ${asientoSeleccionado.fila}, Asiento ${asientoSeleccionado.numero}`
      });
      setAsientoSeleccionado(null);
      setTiempoRestante(0);
      cargarMapa(eventoSeleccionado.id);
      const tk = await obtenerMisTickets();
      setListaTickets(tk.tickets || []);
      setTab('tickets');
    } catch (err) { mostrarError(err, 'Error al procesar el pago'); }
  };

  const cargarMisTickets = async () => {
    try {
      const tk = await obtenerMisTickets();
      setListaTickets(tk.tickets || []);
    } catch (err) { mostrarError(err, 'No se pudieron cargar tus entradas'); }
  };

  const handleValidar = async (e) => {
    e.preventDefault();
    if (!codigoValidar) return;
    try {
      const res = await validarTicket(codigoValidar);
      setResultadoValidacion(res);
    } catch (err) {
      setResultadoValidacion(err.response?.data || { estado: 'ERROR', mensaje: '❌ Error al validar' });
    }
    setCodigoValidar('');
  };

  const formatTimer = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const esAdmin = usuario?.rol === 'admin';
  const esStaff = usuario?.rol === 'admin' || usuario?.rol === 'validador';

  return (
    <div className="min-h-screen bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.25),rgba(255,255,255,0))] text-slate-100 flex flex-col items-center p-4 md:p-8 font-sans">

      <header className="w-full max-w-5xl flex flex-col md:flex-row justify-between items-center p-6 rounded-3xl bg-slate-900/60 backdrop-blur-2xl border border-white/10 mb-8">
        <div>
          <span className="text-[10px] uppercase font-extrabold tracking-widest text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">
            Base local funcional
          </span>
          <h1 className="text-3xl font-black bg-gradient-to-r from-white via-slate-200 to-indigo-300 bg-clip-text text-transparent mt-1">
            EuroTickets
          </h1>
        </div>
        {usuario && (
          <div className="flex items-center gap-3 mt-4 md:mt-0">
            <span className="text-xs font-bold bg-white/5 border border-white/10 px-4 py-2 rounded-2xl">
              👤 {usuario.nombre} ({usuario.rol})
            </span>
            <button onClick={handleLogout} className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs px-4 py-2 rounded-2xl transition">
              Salir
            </button>
          </div>
        )}
      </header>

      {mensaje.texto && (
        <div className={`w-full max-w-md p-4 mb-6 rounded-2xl text-center text-xs font-bold border ${
          mensaje.tipo === 'exito' ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300' : 'bg-rose-950/80 border-rose-500/50 text-rose-300'
        }`}>
          {mensaje.texto}
        </div>
      )}

      {!usuario ? (
        <div className="bg-slate-900/60 backdrop-blur-2xl border border-white/10 p-8 rounded-3xl w-full max-w-md space-y-6">
          <h2 className="text-2xl font-bold text-center">Inicia Sesión</h2>
          <p className="text-[11px] text-slate-400 text-center">
            Usuarios de prueba (tras ejecutar <code>npm run seed</code>): admin@eurotickets.com / 123456
          </p>
          <form onSubmit={handleLogin} className="space-y-4">
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-slate-950/60 border border-white/10 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-500" required />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-slate-950/60 border border-white/10 rounded-xl p-3 text-sm focus:outline-none focus:border-indigo-500" required />
            <button type="submit" className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 font-bold py-3.5 rounded-xl text-sm hover:opacity-90 transition">Ingresar</button>
          </form>
        </div>
      ) : (
        <div className="w-full max-w-5xl space-y-8">

          <div className="flex flex-wrap gap-2 p-2 rounded-2xl bg-slate-900/40 backdrop-blur-xl border border-white/10">
            <button onClick={() => setTab('eventos')} className={`px-5 py-2.5 rounded-xl font-bold text-xs transition ${tab === 'eventos' ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}>
              🎫 Eventos y Compra
            </button>
            <button onClick={() => { setTab('tickets'); cargarMisTickets(); }} className={`px-5 py-2.5 rounded-xl font-bold text-xs transition ${tab === 'tickets' ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}>
              🎟️ Mis Entradas
            </button>
            {esStaff && (
              <button onClick={() => setTab('validar')} className={`px-5 py-2.5 rounded-xl font-bold text-xs transition ${tab === 'validar' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}>
                📱 Validar en Puerta
              </button>
            )}
          </div>

          {tab === 'eventos' && (
            <div className="space-y-6">
              {esAdmin && (
                <form onSubmit={handleCrearEvento} className="bg-slate-900/60 backdrop-blur-2xl border border-white/10 p-6 rounded-3xl space-y-4">
                  <h3 className="text-sm font-bold text-indigo-300 uppercase">Crear Evento (Admin)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <input placeholder="Nombre del evento" value={nuevoEvento.nombre} onChange={(e) => setNuevoEvento({ ...nuevoEvento, nombre: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-3 text-xs" required />
                    <input type="datetime-local" value={nuevoEvento.fecha} onChange={(e) => setNuevoEvento({ ...nuevoEvento, fecha: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-3 text-xs" required />
                    <input placeholder="Nombre del recinto" value={nuevoEvento.recinto_nombre} onChange={(e) => setNuevoEvento({ ...nuevoEvento, recinto_nombre: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-3 text-xs" required />
                    <input placeholder="Dirección del recinto" value={nuevoEvento.recinto_direccion} onChange={(e) => setNuevoEvento({ ...nuevoEvento, recinto_direccion: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-3 text-xs" />
                    <input placeholder="URL de imagen (banner)" value={nuevoEvento.imagen_url} onChange={(e) => setNuevoEvento({ ...nuevoEvento, imagen_url: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-3 text-xs" />
                    <input placeholder="Descripción" value={nuevoEvento.descripcion} onChange={(e) => setNuevoEvento({ ...nuevoEvento, descripcion: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-3 text-xs" />
                  </div>
                  <button type="submit" className="bg-emerald-600 font-bold px-6 py-2.5 rounded-xl text-xs">Guardar Evento</button>
                </form>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {listaEventos.map((ev) => (
                  <button key={ev.id} onClick={() => seleccionarEvento(ev)} className={`text-left bg-slate-900/60 backdrop-blur-2xl border p-5 rounded-3xl transition ${eventoSeleccionado?.id === ev.id ? 'border-indigo-500' : 'border-white/10 hover:border-white/30'}`}>
                    <h4 className="font-bold text-base text-white">{ev.nombre}</h4>
                    <p className="text-xs text-slate-400 mt-1">📍 {ev.recinto_nombre} — {ev.recinto_direccion}</p>
                    <p className="text-[11px] text-indigo-400 mt-1">{new Date(ev.fecha).toLocaleString('es-ES')}</p>
                  </button>
                ))}
                {listaEventos.length === 0 && (
                  <p className="text-xs text-slate-500 col-span-2 text-center py-8">No hay eventos todavía. {esAdmin ? 'Crea el primero arriba, o corre "npm run seed" en el backend.' : 'Pídele a un administrador que cree uno, o corre "npm run seed" en el backend.'}</p>
                )}
              </div>

              {eventoSeleccionado && (
                <div className="bg-slate-900/60 backdrop-blur-2xl border border-white/10 p-6 rounded-3xl space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-bold text-slate-200">🗺️ {eventoSeleccionado.nombre} — Selecciona tu asiento</h3>
                    <span className={`text-xl font-black font-mono ${tiempoRestante > 0 ? 'text-amber-400 animate-pulse' : 'text-slate-600'}`}>
                      {tiempoRestante > 0 ? formatTimer(tiempoRestante) : '—'}
                    </span>
                  </div>

                  {mapaData.zonas.length === 0 && (
                    <p className="text-xs text-slate-500">Este evento todavía no tiene zonas configuradas.</p>
                  )}

                  {mapaData.zonas.map((zona) => {
                    const asientosZona = mapaData.asientos.filter((a) => a.zona_id === zona.id);
                    const filas = [...new Set(asientosZona.map((a) => a.fila))];
                    return (
                      <div key={zona.id} className="space-y-2 pt-3 border-t border-white/10">
                        <span className="text-xs font-bold" style={{ color: zona.color }}>{zona.nombre} — {zona.precio}€</span>
                        {filas.map((fila) => (
                          <div key={fila} className="flex flex-wrap gap-2">
                            {asientosZona.filter((a) => a.fila === fila).map((asiento) => {
                              let clase = ESTADOS_COLOR.disponible;
                              if (asiento.estado === 'vendido') clase = ESTADOS_COLOR.vendido;
                              else if (asientoSeleccionado?.id === asiento.id) clase = ESTADOS_COLOR.reservado_mio;
                              else if (asiento.estado === 'reservado') clase = ESTADOS_COLOR.reservado_otro;

                              return (
                                <button key={asiento.id} onClick={() => handleClickAsiento(asiento, zona)} className={`h-8 px-3 rounded-lg text-xs font-bold transition border ${clase}`}>
                                  {fila}{asiento.numero}
                                </button>
                              );
                            })}
                          </div>
                        ))}
                      </div>
                    );
                  })}

                  {esAdmin && (
                    <form onSubmit={handleAgregarZona} className="pt-4 border-t border-white/10 space-y-3">
                      <h4 className="text-xs font-bold text-indigo-300 uppercase">Agregar zona al mapa (Admin)</h4>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                        <input placeholder="Nombre zona" value={nuevaZonaForm.nombre} onChange={(e) => setNuevaZonaForm({ ...nuevaZonaForm, nombre: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-2 text-xs" required />
                        <input placeholder="Precio" type="number" step="0.01" value={nuevaZonaForm.precio} onChange={(e) => setNuevaZonaForm({ ...nuevaZonaForm, precio: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-2 text-xs" required />
                        <input placeholder="Letra de fila (ej: A)" value={nuevaZonaForm.fila} onChange={(e) => setNuevaZonaForm({ ...nuevaZonaForm, fila: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-2 text-xs" required />
                        <input placeholder="Asientos en la fila" type="number" value={nuevaZonaForm.cantidad} onChange={(e) => setNuevaZonaForm({ ...nuevaZonaForm, cantidad: e.target.value })} className="bg-slate-950/60 border border-white/10 rounded-xl p-2 text-xs" required />
                        <button type="submit" className="bg-indigo-600 hover:bg-indigo-500 font-bold rounded-xl text-xs">Agregar</button>
                      </div>
                    </form>
                  )}

                  {asientoSeleccionado && (
                    <div className="bg-slate-950/80 border border-indigo-500/50 p-5 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-4">
                      <div>
                        <span className="text-[10px] text-indigo-400 font-bold uppercase block">Asiento reservado para ti</span>
                        <span className="text-sm font-bold text-white">{asientoSeleccionado.zonaNombre} — Fila {asientoSeleccionado.fila}, Asiento {asientoSeleccionado.numero}</span>
                        <span className="text-xs text-emerald-400 block">{asientoSeleccionado.precio}€</span>
                      </div>
                      <button onClick={handleComprar} className="bg-gradient-to-r from-emerald-500 to-teal-600 font-bold px-6 py-3 rounded-2xl text-xs hover:opacity-90 transition">
                        💳 Confirmar Compra
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {tab === 'tickets' && (
            <div className="space-y-4">
              {listaTickets.length === 0 && <p className="text-xs text-slate-500 text-center py-8">Todavía no tienes entradas compradas.</p>}
              {listaTickets.map((ticket) => (
                <div key={ticket.id} className="bg-slate-900/60 backdrop-blur-2xl border border-white/10 p-5 rounded-3xl flex justify-between items-center">
                  <div>
                    <span className="font-extrabold text-indigo-400 font-mono text-xs">{ticket.codigo_qr}</span>
                    <h4 className="text-base font-bold text-white mt-1">{ticket.evento_nombre}</h4>
                    <p className="text-xs text-slate-400">{ticket.zona_nombre} — Fila {ticket.fila}, Asiento {ticket.numero} — {ticket.precio}€</p>
                    <p className={`text-[11px] mt-1 font-bold ${ticket.estado === 'usado' ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {ticket.estado === 'usado' ? '✅ Ya utilizada' : '🟢 Activa'}
                    </p>
                  </div>
                  <button onClick={() => setTicketModal({ codigoQr: ticket.codigo_qr, evento: ticket.evento_nombre, asiento: `${ticket.zona_nombre} — Fila ${ticket.fila}, Asiento ${ticket.numero}` })} className="bg-indigo-600 hover:bg-indigo-500 text-xs font-bold px-4 py-2.5 rounded-xl transition">
                    👁️ Ver QR
                  </button>
                </div>
              ))}
            </div>
          )}

          {tab === 'validar' && esStaff && (
            <div className="bg-slate-900/60 backdrop-blur-2xl border border-white/10 p-6 rounded-3xl space-y-4">
              <h2 className="text-lg font-bold">📱 Validación de Entradas en Puerta</h2>
              <form onSubmit={handleValidar} className="flex gap-2">
                <input type="text" placeholder="Código QR (ej: ET-1234567890-5)" value={codigoValidar} onChange={(e) => setCodigoValidar(e.target.value)} className="flex-1 bg-slate-950/60 border border-white/10 p-3 rounded-xl text-xs font-mono" />
                <button type="submit" className="bg-emerald-600 font-bold px-6 py-3 rounded-xl text-xs">Validar</button>
              </form>
              {resultadoValidacion && (
                <div className={`p-6 rounded-2xl border text-center ${resultadoValidacion.estado === 'VALIDO' ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200' : 'bg-rose-950/80 border-rose-500 text-rose-200'}`}>
                  <h3 className="text-xl font-black">{resultadoValidacion.mensaje}</h3>
                  {resultadoValidacion.fechaValidacion && (
                    <p className="text-xs mt-2">Validada previamente el: {new Date(resultadoValidacion.fechaValidacion).toLocaleString('es-ES')}</p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {ticketModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-white/10 w-full max-w-md rounded-3xl overflow-hidden p-6 text-center space-y-5">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="text-lg font-black text-white">EUROTICKETS PASS</h3>
              <button onClick={() => setTicketModal(null)} className="text-slate-400 font-bold">✕</button>
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-white/5 space-y-3">
              <h4 className="text-base font-bold text-white">{ticketModal.evento}</h4>
              <p className="text-xs text-indigo-400 font-bold">{ticketModal.asiento}</p>
              <div className="flex justify-center p-4 bg-white rounded-2xl">
                <QRCodeSVG value={ticketModal.codigoQr} size={150} />
              </div>
              <p className="text-[10px] font-mono text-slate-500">{ticketModal.codigoQr}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
