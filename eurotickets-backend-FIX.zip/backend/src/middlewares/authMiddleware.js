const jwt = require('jsonwebtoken');

const verificarToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Formato esperado: Bearer <TOKEN>

  if (!token) {
    return res.status(401).json({ ok: false, mensaje: 'Acceso denegado: token no proporcionado.' });
  }

  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (error) {
    return res.status(403).json({ ok: false, mensaje: 'Token inválido o expirado.' });
  }
};

const esAdmin = (req, res, next) => {
  if (req.usuario && req.usuario.rol === 'admin') return next();
  return res.status(403).json({ ok: false, mensaje: 'Acceso restringido: requiere rol de administrador.' });
};

// Admin o Validador de puerta (para el escáner de accesos)
const esStaff = (req, res, next) => {
  if (req.usuario && ['admin', 'validador'].includes(req.usuario.rol)) return next();
  return res.status(403).json({ ok: false, mensaje: 'Acceso restringido: requiere rol de staff.' });
};

module.exports = { verificarToken, esAdmin, esStaff };
