require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./db');

const sembrar = async () => {
  try {
    console.log('🌱 Sembrando datos de prueba...');

    await db.query('SET FOREIGN_KEY_CHECKS = 0');
    await db.query('DELETE FROM tickets');
    await db.query('DELETE FROM asientos');
    await db.query('DELETE FROM zonas');
    await db.query('DELETE FROM eventos');
    await db.query('DELETE FROM recintos');
    await db.query('DELETE FROM usuarios');
    await db.query('SET FOREIGN_KEY_CHECKS = 1');

    const passwordHash = await bcrypt.hash('123456', 10);

    await db.query(
      'INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)',
      ['Administrador', 'admin@eurotickets.com', passwordHash, 'admin']
    );
    await db.query(
      'INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)',
      ['Validador Puerta', 'validador@eurotickets.com', passwordHash, 'validador']
    );
    await db.query(
      'INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)',
      ['Fan Demo', 'fan@eurotickets.com', passwordHash, 'fan']
    );

    const [recinto] = await db.query(
      'INSERT INTO recintos (nombre, direccion) VALUES (?, ?)',
      ['Estadio Metropolitano', 'Av. de Luis Aragonés 4, Madrid']
    );

    const [evento] = await db.query(
      'INSERT INTO eventos (recinto_id, nombre, descripcion, fecha, imagen_url) VALUES (?, ?, ?, ?, ?)',
      [
        recinto.insertId,
        'EuroTickets Tour 2026',
        'Concierto inaugural de la gira europea.',
        '2026-05-15 21:00:00',
        'https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?auto=format&fit=crop&w=1200&q=80'
      ]
    );

    const [zonaVip] = await db.query(
      'INSERT INTO zonas (evento_id, nombre, precio, color) VALUES (?, ?, ?, ?)',
      [evento.insertId, 'Fila A (VIP)', 80.0, '#eab308']
    );
    const [zonaPref] = await db.query(
      'INSERT INTO zonas (evento_id, nombre, precio, color) VALUES (?, ?, ?, ?)',
      [evento.insertId, 'Fila B (Preferente)', 60.0, '#6366f1']
    );

    const generarFila = async (zonaId, fila, cantidad) => {
      for (let i = 1; i <= cantidad; i++) {
        await db.query('INSERT INTO asientos (zona_id, fila, numero) VALUES (?, ?, ?)', [zonaId, fila, i]);
      }
    };
    await generarFila(zonaVip.insertId, 'A', 8);
    await generarFila(zonaPref.insertId, 'B', 8);

    console.log('✅ Datos de prueba creados.');
    console.log('   Admin:      admin@eurotickets.com / 123456');
    console.log('   Validador:  validador@eurotickets.com / 123456');
    console.log('   Fan:        fan@eurotickets.com / 123456');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error al sembrar datos:', error.message);
    process.exit(1);
  }
};

sembrar();
