const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'eurotickets',
  port: process.env.DB_PORT ? parseInt(process.env.DB_PORT) : 3306,
  charset: 'utf8mb4',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const verificarConexion = async (maxIntentos = 10, esperaMs = 2000) => {
  for (let intento = 1; intento <= maxIntentos; intento++) {
    try {
      const connection = await pool.getConnection();
      console.log('✅ Conexión exitosa a la base de datos MySQL (EuroTickets)');
      connection.release();
      return true;
    } catch (error) {
      console.log(`⏳ Esperando a MySQL... (Intento ${intento}/${maxIntentos})`);
      if (intento === maxIntentos) {
        console.error('❌ Error al conectar con la base de datos MySQL:', error.message);
      } else {
        await new Promise((resolve) => setTimeout(resolve, esperaMs));
      }
    }
  }
  return false;
};

verificarConexion();

module.exports = pool;
