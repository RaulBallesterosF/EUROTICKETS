const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRoutes = require('./routes/authRoutes');
const eventosRoutes = require('./routes/eventosRoutes');
const ticketsRoutes = require('./routes/ticketsRoutes');
const { liberarBloqueosExpirados } = require('./controllers/ticketsController');

const app = express();

// Un origen concreto, no '*' — '*' junto con credentials:true es una
// combinación que los navegadores rechazan (o que, si se fuerza, abre
// la API a cualquier sitio).
const corsOrigin = process.env.CORS_ORIGIN || 'http://localhost:5173';
app.use(cors({ origin: corsOrigin, credentials: true }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true, mensaje: 'EuroTickets backend activo' }));

app.use('/api/auth', authRoutes);
app.use('/api/eventos', eventosRoutes);
app.use('/api/tickets', ticketsRoutes);

// Cada 30s libera asientos cuya reserva de 10 minutos expiró sin compra.
setInterval(liberarBloqueosExpirados, 30 * 1000);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Servidor EuroTickets escuchando en http://localhost:${PORT}`));
