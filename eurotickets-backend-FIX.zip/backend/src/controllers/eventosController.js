const db = require('../config/db');

const obtenerEventos = async (req, res) => {
  try {
    const [eventos] = await db.query(
      `SELECT e.id, e.nombre, e.descripcion, e.fecha, e.imagen_url,
              r.nombre AS recinto_nombre, r.direccion AS recinto_direccion
       FROM eventos e
       JOIN recintos r ON e.recinto_id = r.id
       WHERE e.activo = 1
       ORDER BY e.fecha ASC`
    );
    res.json({ ok: true, eventos });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al obtener los eventos', error: error.message });
  }
};

const crearEvento = async (req, res) => {
  const { nombre, descripcion, fecha, imagen_url, recinto_nombre, recinto_direccion } = req.body;

  if (!nombre || !fecha || !recinto_nombre) {
    return res.status(400).json({ ok: false, mensaje: 'nombre, fecha y recinto_nombre son obligatorios.' });
  }

  try {
    const [recinto] = await db.query(
      'INSERT INTO recintos (nombre, direccion) VALUES (?, ?)',
      [recinto_nombre, recinto_direccion || '']
    );

    const [evento] = await db.query(
      'INSERT INTO eventos (recinto_id, nombre, descripcion, fecha, imagen_url) VALUES (?, ?, ?, ?, ?)',
      [recinto.insertId, nombre, descripcion || '', fecha, imagen_url || '']
    );

    res.status(201).json({ ok: true, mensaje: 'Evento creado exitosamente', eventoId: evento.insertId });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al crear el evento', error: error.message });
  }
};

const eliminarEvento = async (req, res) => {
  try {
    await db.query('UPDATE eventos SET activo = 0 WHERE id = ?', [req.params.id]);
    res.json({ ok: true, mensaje: 'Evento desactivado' });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al eliminar el evento', error: error.message });
  }
};

module.exports = { obtenerEventos, crearEvento, eliminarEvento };
