const db = require('../config/db');

const obtenerMapaEvento = async (req, res) => {
  try {
    const { eventoId } = req.params;
    const [zonas] = await db.query('SELECT id, nombre, precio, color FROM zonas WHERE evento_id = ?', [eventoId]);
    const [asientos] = await db.query(
      `SELECT a.id, a.zona_id, a.fila, a.numero, a.estado, a.bloqueado_por, a.bloqueado_hasta
       FROM asientos a
       JOIN zonas z ON a.zona_id = z.id
       WHERE z.evento_id = ?
       ORDER BY a.fila, a.numero`,
      [eventoId]
    );
    res.json({ ok: true, zonas, asientos });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al obtener el mapa del evento', error: error.message });
  }
};

// Crea (o reemplaza) las zonas y asientos de un evento.
// Versión mínima del "SeatMap Studio": sin editor visual en canvas todavía,
// pero con la misma estructura de datos de destino.
const configurarMapa = async (req, res) => {
  const { eventoId } = req.params;
  const { zonas } = req.body; // [{ nombre, precio, color, filas: [{ fila, cantidad }] }]

  if (!Array.isArray(zonas) || zonas.length === 0) {
    return res.status(400).json({ ok: false, mensaje: 'zonas debe ser un arreglo con al menos una zona.' });
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    await conn.query('DELETE FROM zonas WHERE evento_id = ?', [eventoId]);

    for (const zona of zonas) {
      const [zonaResult] = await conn.query(
        'INSERT INTO zonas (evento_id, nombre, precio, color) VALUES (?, ?, ?, ?)',
        [eventoId, zona.nombre, zona.precio, zona.color || '#3b82f6']
      );
      for (const fila of zona.filas || []) {
        for (let i = 1; i <= fila.cantidad; i++) {
          await conn.query('INSERT INTO asientos (zona_id, fila, numero) VALUES (?, ?, ?)', [zonaResult.insertId, fila.fila, i]);
        }
      }
    }

    await conn.commit();
    res.json({ ok: true, mensaje: 'Mapa del evento configurado correctamente' });
  } catch (error) {
    await conn.rollback();
    res.status(500).json({ ok: false, mensaje: 'Error al configurar el mapa', error: error.message });
  } finally {
    conn.release();
  }
};

// Bloqueo atómico de 10 minutos (SeatLock).
// El UPDATE con WHERE es atómico a nivel de fila en MySQL: si dos usuarios
// intentan bloquear el mismo asiento a la vez, solo uno obtiene affectedRows=1.
const bloquearAsiento = async (req, res) => {
  const { asientoId } = req.body;
  const usuarioId = req.usuario.id;

  if (!asientoId) return res.status(400).json({ ok: false, mensaje: 'asientoId es obligatorio.' });

  try {
    const [resultado] = await db.query(
      `UPDATE asientos
       SET estado = 'reservado', bloqueado_por = ?, bloqueado_hasta = DATE_ADD(NOW(), INTERVAL 10 MINUTE)
       WHERE id = ? AND (estado = 'disponible' OR (estado = 'reservado' AND bloqueado_hasta < NOW()))`,
      [usuarioId, asientoId]
    );

    if (resultado.affectedRows === 0) {
      return res.status(409).json({ ok: false, mensaje: 'El asiento ya no está disponible.' });
    }

    res.json({ ok: true, mensaje: 'Asiento reservado por 10 minutos.', expiraEn: Date.now() + 10 * 60 * 1000 });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al bloquear el asiento', error: error.message });
  }
};

const liberarAsiento = async (req, res) => {
  const { asientoId } = req.body;
  const usuarioId = req.usuario.id;

  try {
    await db.query(
      `UPDATE asientos SET estado = 'disponible', bloqueado_por = NULL, bloqueado_hasta = NULL
       WHERE id = ? AND bloqueado_por = ?`,
      [asientoId, usuarioId]
    );
    res.json({ ok: true, mensaje: 'Asiento liberado.' });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al liberar el asiento', error: error.message });
  }
};

const comprarTicket = async (req, res) => {
  const { asientoId } = req.body;
  const usuarioId = req.usuario.id;

  if (!asientoId) return res.status(400).json({ ok: false, mensaje: 'asientoId es obligatorio.' });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    const [rows] = await conn.query('SELECT * FROM asientos WHERE id = ? FOR UPDATE', [asientoId]);
    if (rows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ ok: false, mensaje: 'Asiento no encontrado.' });
    }

    const asiento = rows[0];
    const reservadoPorMi =
      asiento.estado === 'reservado' &&
      asiento.bloqueado_por === usuarioId &&
      asiento.bloqueado_hasta &&
      new Date(asiento.bloqueado_hasta) > new Date();

    if (!reservadoPorMi) {
      await conn.rollback();
      return res.status(409).json({ ok: false, mensaje: 'El asiento no está reservado para ti o la reserva expiró.' });
    }

    const codigoQr = `ET-${Date.now()}-${asientoId}`;
    await conn.query(
      `UPDATE asientos SET estado = 'vendido', bloqueado_por = NULL, bloqueado_hasta = NULL WHERE id = ?`,
      [asientoId]
    );
    const [ticket] = await conn.query(
      'INSERT INTO tickets (asiento_id, usuario_id, codigo_qr) VALUES (?, ?, ?)',
      [asientoId, usuarioId, codigoQr]
    );

    await conn.commit();
    res.status(201).json({ ok: true, mensaje: 'Compra procesada con éxito.', ticketId: ticket.insertId, codigoQr });
  } catch (error) {
    await conn.rollback();
    res.status(500).json({ ok: false, mensaje: 'Error al procesar la compra', error: error.message });
  } finally {
    conn.release();
  }
};

const misTickets = async (req, res) => {
  try {
    const [tickets] = await db.query(
      `SELECT t.id, t.codigo_qr, t.estado, t.fecha_validacion,
              a.fila, a.numero, z.nombre AS zona_nombre, z.precio,
              e.nombre AS evento_nombre, e.fecha
       FROM tickets t
       JOIN asientos a ON t.asiento_id = a.id
       JOIN zonas z ON a.zona_id = z.id
       JOIN eventos e ON z.evento_id = e.id
       WHERE t.usuario_id = ?
       ORDER BY t.creado_en DESC`,
      [req.usuario.id]
    );
    res.json({ ok: true, tickets });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al obtener tickets', error: error.message });
  }
};

const validarTicket = async (req, res) => {
  const { codigoQr } = req.params;
  try {
    const [rows] = await db.query('SELECT * FROM tickets WHERE codigo_qr = ?', [codigoQr]);
    if (rows.length === 0) {
      return res.status(404).json({ ok: false, estado: 'INVALIDO', mensaje: '❌ Entrada no encontrada o falsificada' });
    }

    const ticket = rows[0];
    if (ticket.estado === 'usado') {
      return res.status(400).json({
        ok: false,
        estado: 'USADO',
        mensaje: '⚠️ Entrada ya utilizada previamente',
        fechaValidacion: ticket.fecha_validacion
      });
    }

    await db.query("UPDATE tickets SET estado = 'usado', fecha_validacion = NOW() WHERE id = ?", [ticket.id]);
    res.json({ ok: true, estado: 'VALIDO', mensaje: '✅ Acceso autorizado' });
  } catch (error) {
    res.status(500).json({ ok: false, mensaje: 'Error al validar el ticket', error: error.message });
  }
};

// Libera periódicamente los asientos cuya reserva de 10 minutos expiró
// sin que se completara la compra. Sustituye, a escala local, al worker
// de expiración que en producción haría Redis.
const liberarBloqueosExpirados = async () => {
  try {
    const [resultado] = await db.query(
      `UPDATE asientos SET estado = 'disponible', bloqueado_por = NULL, bloqueado_hasta = NULL
       WHERE estado = 'reservado' AND bloqueado_hasta < NOW()`
    );
    if (resultado.affectedRows > 0) {
      console.log(`🔓 ${resultado.affectedRows} asiento(s) liberado(s) por expiración de reserva.`);
    }
  } catch (error) {
    console.error('Error liberando bloqueos expirados:', error.message);
  }
};

module.exports = {
  obtenerMapaEvento,
  configurarMapa,
  bloquearAsiento,
  liberarAsiento,
  comprarTicket,
  misTickets,
  validarTicket,
  liberarBloqueosExpirados
};
