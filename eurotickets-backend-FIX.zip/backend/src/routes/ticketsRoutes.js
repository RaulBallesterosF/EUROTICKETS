const express = require('express');
const router = express.Router();
const ticketsController = require('../controllers/ticketsController');
const { verificarToken, esAdmin, esStaff } = require('../middlewares/authMiddleware');

router.get('/mapa/:eventoId', ticketsController.obtenerMapaEvento);
router.post('/mapa/:eventoId/configurar', [verificarToken, esAdmin], ticketsController.configurarMapa);

router.post('/bloquear', verificarToken, ticketsController.bloquearAsiento);
router.post('/liberar', verificarToken, ticketsController.liberarAsiento);
router.post('/comprar', verificarToken, ticketsController.comprarTicket);

router.get('/mis-tickets', verificarToken, ticketsController.misTickets);
router.post('/validar/:codigoQr', [verificarToken, esStaff], ticketsController.validarTicket);

module.exports = router;
