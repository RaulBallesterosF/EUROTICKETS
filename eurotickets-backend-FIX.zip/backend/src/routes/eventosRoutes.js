const express = require('express');
const router = express.Router();
const { obtenerEventos, crearEvento, eliminarEvento } = require('../controllers/eventosController');
const { verificarToken, esAdmin } = require('../middlewares/authMiddleware');

router.get('/', obtenerEventos);
router.post('/', [verificarToken, esAdmin], crearEvento);
router.delete('/:id', [verificarToken, esAdmin], eliminarEvento);

module.exports = router;
