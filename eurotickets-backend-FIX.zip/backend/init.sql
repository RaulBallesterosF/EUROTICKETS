-- Esquema único de EuroTickets.
-- Sustituye por completo a init.sql y seed.js antiguos, que definían
-- tablas y estados de asiento distintos e incompatibles entre sí.

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  rol ENUM('admin', 'validador', 'fan') DEFAULT 'fan',
  device_token VARCHAR(255),
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS recintos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  direccion VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS eventos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recinto_id INT NOT NULL,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  fecha DATETIME NOT NULL,
  imagen_url VARCHAR(500),
  activo TINYINT(1) DEFAULT 1,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (recinto_id) REFERENCES recintos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS zonas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  evento_id INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  precio DECIMAL(10, 2) NOT NULL,
  color VARCHAR(20) DEFAULT '#3b82f6',
  FOREIGN KEY (evento_id) REFERENCES eventos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- estado + bloqueado_hasta es el mecanismo de "SeatLock" de 10 minutos:
-- en vez de Redis (como pedía la especificación original), se resuelve
-- con una columna de expiración y una tarea periódica en el backend.
-- Es la base correcta; migrar a Redis más adelante no cambia la lógica,
-- solo dónde vive el estado.
CREATE TABLE IF NOT EXISTS asientos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  zona_id INT NOT NULL,
  fila VARCHAR(10) NOT NULL,
  numero INT NOT NULL,
  estado ENUM('disponible', 'reservado', 'vendido') DEFAULT 'disponible',
  bloqueado_por INT NULL,
  bloqueado_hasta DATETIME NULL,
  FOREIGN KEY (zona_id) REFERENCES zonas(id) ON DELETE CASCADE,
  FOREIGN KEY (bloqueado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  asiento_id INT NOT NULL,
  usuario_id INT NOT NULL,
  codigo_qr VARCHAR(100) UNIQUE NOT NULL,
  estado ENUM('activo', 'usado') DEFAULT 'activo',
  fecha_validacion DATETIME NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (asiento_id) REFERENCES asientos(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;
